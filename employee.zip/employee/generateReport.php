<?php
    require_once('connect.php');
    //require('fpdf.php');
    require('sector.php');
    $date1 = $_POST['startdate'];
    $date2 = $_POST['enddate'];
    //print_r(array_keys($_POST));
  
    //echo('hello');

    //$date1 = '2017-1-1';
    //$date2 = '2020-1-1';
    $query = "select extract(year from age('" . $date2 . "'::date,'" . $date1 ."'::date))*12 + extract(month from age('" . $date2 . "'::date, '" . $date1 . "'::date));";
    $result = pg_query($db, $query);
    $result1 = pg_fetch_assoc($result);
    $numMonths = $result1['?column?'];

    //print_r(array_keys($result1));

    
    class PDF_Diag extends PDF_Sector {
        
        function fancyTable1($header, $data, $size) {

            $this->SetFillColor(113, 36, 160);
            $this->SetTextColor(255);
            $this->SetDrawColor(113, 36, 160);
            $this->SetLineWidth(.3);
            $this->SetFont('','B');

            for ($i=0; $i<count($header); $i++) {

                $this->Cell(40, 7, $header[$i], 1, 0, 'C', true);

            }

            $this->Ln();
            $this->SetFillColor(224,235,255);
            $this->SetTextColor(0);
            $this->SetFont('');

            $fill = false;
            for($i=0; $i<$size; $i++) {

                if ($i == 5) {
                    break;
                }
                $this->Cell(40, 6, $data[$i]['item_name'], 'LR', 0, 'L', $fill);
                $this->Cell(40, 6, $data[$i]['amount_sold'], 'LR', 0, 'R', $fill);
                $this->Ln();
                $fill = !$fill;

            }

            $this->Cell(80, 0, '', 'T');

            $this->SetDrawColor(200, 200, 200);

        } 
        function fancyTable2($header, $data) {

            $this->SetFillColor(113, 36, 160);
            $this->SetTextColor(255);
            $this->SetDrawColor(113, 36, 160);
            $this->SetLineWidth(.3);
            $this->SetFont('','B');

            for ($i=0; $i<count($header); $i++) {

                $this->Cell(40, 7, $header[$i], 1, 0, 'C', true);

            }

            $this->Ln();
            $this->SetFillColor(224,235,255);
            $this->SetTextColor(0);
            $this->SetFont('');
            $this->SetX(70);

            $fill = false;
            foreach($data as $row) {

                $this->Cell(40, 6, $row['total_orders'], 'LR', 0, 'C', $fill);
                $this->Cell(40, 6, $row['total_revenue'], 'LR', 0, 'C', $fill);
                $this->Ln();
            }

            $this->SetX(70);
            $this->Cell(80, 0, '', 'T');

            $this->SetDrawColor(200, 200, 200);

        }       
        
        var $legends;
        var $wLegend;
        var $sum;
        var $NbVal;
    
        function PieChart($w, $h, $data, $format, $colors=null, $XPage, $YPage)
        {

            $this->SetFont('Courier', '', 10);
            $this->SetLegends($data,$format);
    
            //$XPage = $this->GetX();
            //$YPage = $this->GetY();
            $margin = 2;
            $hLegend = 5;
            $radius = min($w - $margin * 4 - $hLegend - $this->wLegend, $h - $margin * 2);
            $radius = floor($radius / 2);
            $XDiag = $XPage + $margin + $radius;
            $YDiag = $YPage + $margin + $radius;
            if($colors == null) {
                for($i = 0; $i < $this->NbVal; $i++) {
                    $gray = $i * intval(255 / $this->NbVal);
                    $colors[$i] = array($gray,$gray,$gray);
                }
            }
    
            //Sectors
            $this->SetLineWidth(0.2);
            $angleStart = 0;
            $angleEnd = 0;
            $i = 0;
            foreach($data as $val) {
                $angle = ($val * 360) / doubleval($this->sum);
                if ($angle != 0) {
                    $angleEnd = $angleStart + $angle;
                    $this->SetFillColor($colors[$i][0],$colors[$i][1],$colors[$i][2]);
                    $this->Sector($XDiag, $YDiag, $radius, $angleStart, $angleEnd);
                    $angleStart += $angle;
                }
                $i++;
            }
    
            //Legends
            $this->SetFont('Courier', '', 10);
            $x1 = $XPage + 2 * $radius + 4 * $margin;
            $x2 = $x1 + $hLegend + $margin;
            $y1 = $YDiag - $radius + (2 * $radius - $this->NbVal*($hLegend + $margin)) / 2;
            for($i=0; $i<$this->NbVal; $i++) {
                $this->SetFillColor($colors[$i][0],$colors[$i][1],$colors[$i][2]);
                $this->Rect($x1, $y1, $hLegend, $hLegend, 'DF');
                $this->SetXY($x2,$y1);
                $this->Cell(0,$hLegend,$this->legends[$i]);
                $y1+=$hLegend + $margin;
            }
        }
    
        function BarDiagram($w, $h, $data, $format, $color=null, $maxVal=0, $nbDiv=4)
        {
            $this->SetFont('Courier', '', 10);
            $this->SetLegends($data,$format);
    
            $XPage = $this->GetX();
            $YPage = $this->GetY();
            $margin = 2;
            $YDiag = $YPage + $margin;
            $hDiag = floor($h - $margin * 2);
            $XDiag = $XPage + $margin * 2 + $this->wLegend;
            $lDiag = floor($w - $margin * 3 - $this->wLegend);
            if($color == null)
                $color=array(155,155,155);
            if ($maxVal == 0) {
                $maxVal = max($data);
            }
            $valIndRepere = ceil($maxVal / $nbDiv);
            $maxVal = $valIndRepere * $nbDiv;
            $lRepere = floor($lDiag / $nbDiv);
            $lDiag = $lRepere * $nbDiv;
            $unit = $lDiag / $maxVal;
            $hBar = floor($hDiag / ($this->NbVal + 1));
            $hDiag = $hBar * ($this->NbVal + 1);
            $eBaton = floor($hBar * 80 / 100);
    
            $this->SetLineWidth(0.2);
            $this->Rect($XDiag, $YDiag, $lDiag, $hDiag);
    
            $this->SetFont('Courier', '', 10);
            $this->SetFillColor($color[0],$color[1],$color[2]);
            $i=0;
            foreach($data as $val) {
                //Bar
                $xval = $XDiag;
                $lval = (int)($val * $unit);
                $yval = $YDiag + ($i + 1) * $hBar - $eBaton / 2;
                $hval = $eBaton;
                $this->Rect($xval, $yval, $lval, $hval, 'DF');
                //Legend
                $this->SetXY(0, $yval);
                $this->Cell($xval - $margin, $hval, $this->legends[$i],0,0,'R');
                $i++;
            }
    
            //Scales
            for ($i = 0; $i <= $nbDiv; $i++) {
                $xpos = $XDiag + $lRepere * $i;
                $this->Line($xpos, $YDiag, $xpos, $YDiag + $hDiag);
                $val = $i * $valIndRepere;
                $xpos = $XDiag + $lRepere * $i - $this->GetStringWidth($val) / 2;
                $ypos = $YDiag + $hDiag - $margin;
                $this->Text($xpos, $ypos, $val);
            }
        }
    
        function SetLegends($data, $format)
        {
            $this->legends=array();
            $this->wLegend=0;
            $this->sum=array_sum($data);
            $this->NbVal=count($data);
            foreach($data as $l=>$val)
            {
                $p=sprintf('%.2f',$val/$this->sum*100).'%';
                $legend=str_replace(array('%l','%v','%p'),array($l,$val,$p),$format);
                $this->legends[]=$legend;
                $this->wLegend=max($this->GetStringWidth($legend),$this->wLegend);
            }
        }
    }
    $query = "select * from bestSellersBetweenDates('" . $date1 . "'::date, '" . $date2 . "'::date);";
    $result = pg_query($db, $query);
    $data = pg_fetch_all($result);
    $data1 = array();
    for($i=0; $i<count($data); $i++){

        if ($i == 5) {
            break;
        }

        $data1[$data[$i]['item_name']] = $data[$i]['amount_sold'];
        //print_r($data1[$data[$i]['item_name']]);
        
    }
       
    ob_end_clean();
    ob_start();
    $pdf = new PDF_Diag();
    
    $header = array('Item Name', 'Amount Sold');
    //$data = array();
    $pdf->SetFont('Courier', '', 11);
    $pdf->AddPage();
    $pdf->SetMargins(15,15,15);
    $pdf->Image('logo.png');
    $pdf->Cell(4,4,'',0,1);
    $pdf->Ln();
    $pdf->MultiCell(195,6,'Sales Report', 0,'C');
    $pdf->SetDrawColor(0, 0, 0);
    $pdf->Line(20, $pdf->GetY(), 190, $pdf->GetY());
    $pdf->Ln();
    $pdf->MultiCell(180,6, 'EZ Games Sales Report for ' . $date1 . ' through ' . $date2 . ', showing top 5 most popular items and total sales for the time period.',0,'C');
    $pdf->Ln();
    $pdf->Ln();
    //$pdf->Line();
    $pdf->SetFont('Arial', '', 14);
    $pdf->SetX(30);
    $storeY = $pdf->GetY();
    $pdf->Cell(4,4,'Most Popular Items',0,1);
    $pdf->Ln();
    $pdf->fancyTable1($header, $data, count($data));
    $col1=array(244,88,88);
    $col2=array(94,214,108);
    $col3=array(62,90,232);
    $col4=array(242, 244, 88);
    $col5=array(0,240,240);
    $pdf->Cell(0, 5, '', 0, 1);
    //$pdf->SetX(100);
    //$pdf->SetY($storeY);
    $storeY += 5;
    $pdf->PieChart(80, 80, $data1, '%l (%p)', array($col1, $col2, $col3, $col4, $col5), 100, $storeY);
    $pdf->SetFont('Arial', '', 14);
    $pdf->Ln();
    $pdf->Ln();
    $pdf->Ln();
    $pdf->Ln();
    $pdf->SetDrawColor(0, 0, 0);
    $pdf->SetLineWidth(.3);
    $pdf->Line(15, $pdf->GetY(), 195, $pdf->GetY());
    $pdf->Ln();
    $pdf->Ln();

    $pdf->SetX(98);
    $pdf->Cell(4,4, 'Total Sales', 0, 1);
    $pdf->Ln();
    $header = array('Total Orders', 'Total Sales');
    $query = "select * from totalSalesBetweenDates('" . $date1 . "'::date, '" . $date2 . "'::date);";
    $result = pg_query($db, $query);
    $data = pg_fetch_all($result);
    $tableData = $data;
    $data1 = array();

    $startMonth = $date1;
    $endMonth = $startMonth;
    
    //print_r($endMonth);

    for ($i=0; $i<$numMonths; $i++) {
        
        $startMonth = $endMonth;
        $query = "select '" . $endMonth . "'::date + interval '1 month';";
        $result = pg_query($db, $query);
        $result1 = pg_fetch_assoc($result);
        $endMonth = $result1['?column?'];
        $query = "select * from totalSalesBetweenDates('" . $startMonth . "'::date, '" . $endMonth . "'::date);";
        $result = pg_query($db, $query);
        $result1 = pg_fetch_assoc($result);
        array_push($data, $result1);

    }

    for($i=0; $i<count($data); $i++){

        $data1[$data[$i]['start_month']] = $data[$i]['total_revenue'];
        //print_r($data1[$data[$i]['item_name']]);

    }
    $pdf->SetX(70);
    $pdf->fancyTable2($header, $tableData);
    $pdf->Ln();
    $pdf->Ln();
    $pdf->Ln();
    $pdf->Ln();
    $theY = $pdf->GetY();
    $pdf->SetY($theY + 5);
    $pdf->BarDiagram(150, 100, $data1, '%l (%p)', array(255, 0 ,0));
    $pdf->Ln(12);
    $pdf->SetX(40);
    $pdf->Cell(4,4, 'Categories demonstrate sales through the end of each listed month', 0, 1);
    $pdf->Output();
    ob_end_flush();
    
?>