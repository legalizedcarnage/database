<?php
    require_once("./connect.php");

    $item_id = $_POST["itemid"];
    $quantity = $_POST["qty"];
    $warehouse_id = $_POST["wid"];

    $query = "select * from warehouse_inventory w where w.wid = " . $warehouse_id . " and w.iid = " . $item_id . " and w.quantity >= " . $quantity . ";";
    $result = pg_query($db, $query);
    if (pg_num_fields($result) > 0) {

        echo '<script language="javascript">';
        echo 'alert("Inventory satisfies request.")';
        echo '</script>';
    } else {

        echo '<script language="javascript">';
        echo 'alert("Not enough inventory.")';
        echo '</script>';

    }
?>